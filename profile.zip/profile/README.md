![Frame 6693](https://user-images.githubusercontent.com/85264247/177539616-a113dc8d-ec24-4efe-b19e-e85de8685acd.png)


# Rocket Community :rocket:
A Rocket Community é um projeto high-end voltado para a plataforma Multi Theft Auto, que apresenta características próprias e aspectos únicos, que se difere de outros servidores do mesmo segmento. O Projeto surgiu como uma ideia de revolucionar a 3 anos atrás por dois amigos hoje em dia é uma empresa autoral consolidada e adquirida pela varsel.com.br em 2021.  Somos todos jogadores, e por isso sabemos as necessidades e como executa-las, são mais de 7 anos como equipe não só no MTA mas também como empresa trazendo assim a experiência, dedicação & carinho para transformar o Rocket em uma experiência única.
a
